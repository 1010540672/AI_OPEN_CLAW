rootProject.name = "WebViewPerfPlugin"
include(":plugin", ":app", ":monitor-lib")
