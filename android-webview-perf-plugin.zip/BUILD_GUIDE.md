# APK编译完整指南

## 📋 前提条件

编译此Android项目需要以下工具：

### 必需工具

1. **Java JDK 17+**
   - [Eclipse Temurin JDK 17](https://adoptium.net/temurin/releases/?version=17) (推荐)
   - 或 [Oracle JDK 17](https://www.oracle.com/java/technologies/downloads/#java17)

2. **Android SDK**
   - [Android Studio](https://developer.android.com/studio) (推荐，包含SDK)
   - 或单独下载 [Command Line Tools](https://developer.android.com/studio#command-tools)

3. **Gradle 8.2+**
   - 包含在项目中（gradlew）
   - 或手动安装：[Gradle Downloads](https://gradle.org/releases/)

4. **Android SDK组件**
   - Android 14 (API 34) Platform
   - SDK Build-Tools 34.0.0
   - Platform-Tools (adb, fastboot)

---

## 🚀 方式一：使用Android Studio（推荐）

### 步骤1：安装Android Studio

1. 下载并安装 [Android Studio](https://developer.android.com/studio)
2. 启动Android Studio
3. 首次启动时，接受许可协议并安装必要组件

### 步骤2：配置SDK

1. 打开 **Tools → SDK Manager**
2. 在 **SDK Platforms** 选项卡中，勾选：
   - ✅ **Android 14.0 (API 34)**
3. 在 **SDK Tools** 选项卡中，勾选：
   - ✅ **Android SDK Build-Tools 34.0.0**
   - ✅ **Android SDK Platform-Tools**
   - ✅ **Android SDK Command-line Tools (latest)**
4. 点击 **Apply** 安装

### 步骤3：打开项目

1. 选择 **File → Open**
2. 导航到项目目录：`android-webview-perf-plugin`
3. 点击 **OK**
4. 等待Gradle同步完成（首次可能需要几分钟）

### 步骤4：构建APK

1. 在顶部菜单选择 **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. 等待编译完成
3. 编译成功后，右下角会弹出提示：**Build APK(s) completed**
4. 点击提示中的 **locate** 链接，或手动找到：
   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```

### 步骤5：安装到设备

#### 方式A：通过ADB安装

```bash
# 连接设备（确保USB调试已开启）
adb devices

# 安装APK
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

#### 方式B：直接传输

1. 将 `app-debug.apk` 复制到手机
2. 在手机上点击安装
3. 允许"未知来源"应用安装（如果提示）

---

## 🛠️ 方式二：命令行编译

### Linux/macOS

#### 安装Java JDK

```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install -y openjdk-17-jdk

# macOS (使用Homebrew)
brew install openjdk@17
```

#### 安装Android SDK

```bash
# 下载Command Line Tools
cd ~
mkdir -p android-sdk/cmdline-tools
cd android-sdk/cmdline-tools
wget https://dl.google.com/android/repository/commandlinetools-linux-9477386_latest.zip
unzip commandlinetools-linux-9477386_latest.zip
mv cmdline-tools latest

# 设置环境变量（添加到 ~/.bashrc 或 ~/.zshrc）
export ANDROID_HOME=$HOME/android-sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin
export PATH=$PATH:$ANDROID_HOME/platform-tools
export PATH=$PATH:$ANDROID_HOME/build-tools/34.0.0

# 使环境变量生效
source ~/.bashrc
```

#### 接受许可并安装组件

```bash
sdkmanager --licenses
# 输入 y 接受所有许可

sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"
```

#### 编译项目

```bash
cd /path/to/android-webview-perf-plugin

# 使用gradlew（推荐）
chmod +x gradlew
./gradlew clean assembleDebug

# 或使用系统gradle
gradle clean assembleDebug
```

### Windows

#### 安装Java JDK

1. 下载并安装 [Eclipse Temurin JDK 17](https://adoptium.net/temurin/releases/?version=17)
2. 添加到系统PATH（安装程序通常会自动完成）

#### 安装Android SDK

1. 下载并安装 [Android Studio](https://developer.android.com/studio)
2. 或单独下载 [Command Line Tools](https://developer.android.com/studio#command-tools)

#### 配置环境变量

1. 右键"此电脑" → 属性 → 高级系统设置 → 环境变量
2. 新建系统变量：
   - **变量名**: `ANDROID_HOME`
   - **变量值**: `C:\Users\YourName\AppData\Local\Android\Sdk`（你的SDK路径）
3. 编辑系统变量 `Path`，添加：
   - `%ANDROID_HOME%\cmdline-tools\latest\bin`
   - `%ANDROID_HOME%\platform-tools`
   - `%ANDROID_HOME%\build-tools\34.0.0`
4. 重启命令提示符使环境变量生效

#### 接受许可并安装组件

```cmd
sdkmanager --licenses
REM 输入 y 接受所有许可

sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"
```

#### 编译项目

```cmd
cd C:\path\to\android-webview-perf-plugin

# 使用gradlew.bat（推荐）
gradlew.bat clean assembleDebug

# 或使用系统gradle
gradle clean assembleDebug
```

---

## 📦 方式三：使用自动化脚本

项目中提供了编译脚本：

### Linux/macOS

```bash
cd android-webview-perf-plugin
chmod +x build_apk.sh
./build_apk.sh
```

### Windows

```cmd
cd android-webview-perf-plugin
build_apk.bat
```

脚本会自动：
- ✅ 检查Java环境
- ✅ 检查Android SDK
- ✅ 检查必要组件
- ✅ 编译APK
- ✅ 显示APK位置

---

## 🔧 编译配置

### 修改包名

在 `app/build.gradle.kts` 中修改：

```kotlin
defaultConfig {
    applicationId = "com.your.custom.package"  // 修改这里
    // ...
}
```

### 修改应用名称

编辑 `app/src/main/res/values/strings.xml`（创建文件）：

```xml
<resources>
    <string name="app_name">你的应用名称</string>
</resources>
```

### 修改版本号

在 `app/build.gradle.kts` 中：

```kotlin
defaultConfig {
    versionCode = 2      // 版本号
    versionName = "1.1.0"  // 版本名称
    // ...
}
```

---

## 📱 安装APK

### 通过ADB安装

```bash
# 连接设备
adb devices

# 安装（-r 表示覆盖安装）
adb install -r app/build/outputs/apk/debug/app-debug.apk

# 卸载
adb uninstall com.webview.perf.demo
```

### 直接传输

1. 将APK文件传输到手机
2. 在文件管理器中点击APK
3. 允许"未知来源"安装
4. 点击安装

---

## 🐛 常见问题

### Q1: 编译时提示"SDK location not found"

**解决**: 设置 `ANDROID_HOME` 环境变量

```bash
export ANDROID_HOME=/path/to/your/android/sdk
```

### Q2: "Failed to find Build Tools revision 34.0.0"

**解决**: 在SDK Manager中安装 Build-Tools 34.0.0

```bash
sdkmanager "build-tools;34.0.0"
```

### Q3: "Could not resolve com.android.tools.build:gradle:8.2.0"

**解决**: 检查网络连接，或使用国内镜像

在项目根目录的 `build.gradle.kts` 中添加：

```kotlin
repositories {
    maven { url = uri("https://maven.aliyun.com/repository/google") }
    maven { url = uri("https://maven.aliyun.com/repository/public") }
    google()
    mavenCentral()
}
```

### Q4: "Execution failed for task ':app:compileDebugKotlin'"

**解决**: 检查Java版本

```bash
java -version
# 需要Java 17
```

### Q5: ADB无法识别设备

**解决**:
1. 开启USB调试（设置 → 开发者选项）
2. 重新连接USB线
3. 重启ADB服务

```bash
adb kill-server
adb start-server
```

---

## 📊 编译产物

编译成功后，APK位置：

```
app/build/outputs/apk/debug/app-debug.apk
```

APK信息：
- **文件大小**: 约 3-5 MB
- **支持架构**: armeabi-v7a, arm64-v8a, x86, x86_64
- **最低Android版本**: 5.0 (API 21)
- **目标Android版本**: 14 (API 34)

---

## 🔐 发布版APK

编译Release版本（需要签名）：

```bash
./gradlew assembleRelease
```

APK位置：
```
app/build/outputs/apk/release/app-release-unsigned.apk
```

### 签名APK

```bash
# 创建密钥库（首次）
keytool -genkey -v -keystore my-release-key.keystore -alias my-key-alias -keyalg RSA -keysize 2048 -validity 10000

# 签名APK
jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore my-release-key.keystore app-release-unsigned.apk my-key-alias

# 对齐APK
zipalign -v 4 app-release-unsigned.apk app-release-signed-aligned.apk
```

---

## 📚 相关资源

- [Android Developers](https://developer.android.com/)
- [Gradle Documentation](https://docs.gradle.org/)
- [Kotlin for Android](https://developer.android.com/kotlin)
- [Project README](./README.md)
- [FAQ](./FAQ.md)

---

需要帮助？查看 [FAQ.md](./FAQ.md) 或提交Issue。
